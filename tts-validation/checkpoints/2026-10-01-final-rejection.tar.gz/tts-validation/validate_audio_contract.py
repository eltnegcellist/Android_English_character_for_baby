#!/usr/bin/env python3
"""Independent boundary fixtures for output pause scaling/PCM, not input VAD."""
import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'candidates'))
from audio_contract import shorten_pauses,pcm16
cases=[]
def check(name,condition):
    cases.append({'name':name,'passed':bool(condition)})
check('internal threshold retained at 20%',len(shorten_pauses(np.r_[.1,np.zeros(4800),.2]))==962)
check('trailing exact threshold preserved',len(shorten_pauses(np.r_[.1,np.zeros(4800)]))==4801)
check('trailing above threshold shortened',len(shorten_pauses(np.r_[.1,np.zeros(4801)]))==961)
check('short internal interval preserved',len(shorten_pauses(np.r_[.1,np.zeros(4799),.2]))==4801)
check('normal speech untouched',np.array_equal(shorten_pauses(np.full(100,.02,dtype=np.float32)),np.full(100,.02,dtype=np.float32)))
check('PCM truncation matches app contract',np.array_equal(pcm16(np.array([1,-1,.5,-.5])),[32767,-32767,16383,-16383]))
check('PCM zero valid',np.array_equal(pcm16(np.zeros(5)),np.zeros(5)))
for name,data in [('NaN',[float('nan')]),('empty',[]),('infinity',[float('inf')])]:
    try:pcm16(data);valid=False
    except ValueError:valid=True
    check(name+' rejected',valid)
result={'total':len(cases),'failed':sum(not x['passed'] for x in cases),'records':cases,'scope':'Output transformations only; not acoustic equivalence'}
(HERE/'results/audio-contract.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));raise SystemExit(bool(result['failed']))

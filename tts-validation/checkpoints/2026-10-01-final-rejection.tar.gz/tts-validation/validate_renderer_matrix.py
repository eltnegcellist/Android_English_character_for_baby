#!/usr/bin/env python3
"""Candidate only: paired fixed-bank waveforms and all configured-name cases."""
import argparse,json,os,resource,sys,time
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'candidates'))
from validate_g2p import BASE,NAMES,NoEspeak,extract
sys.meta_path.insert(0,NoEspeak())
from utterance_renderer import Renderer
from frontend_fingerprint import frontend_fingerprint
p=argparse.ArgumentParser();p.add_argument('--dictionary',type=Path,required=True);p.add_argument('--assets',type=Path,required=True)
p.add_argument('--names',action='store_true');p.add_argument('--waveform-dir',type=Path)
a=p.parse_args()
gate=json.loads((HERE/'results/lite-word-summary.json').read_text())
if gate['frontend_dependencies_sha256']!=frontend_fingerprint() or gate['failed_occurrences'] or gate['missing_expectations']:
 raise SystemExit('Stale or failed lexical gate; rerun validate_lite_words.py')
renderer=Renderer(a.dictionary,a.assets);banks,hashes=extract(BASE)
cases=[]
if a.names:
 for name in NAMES[1:]:
  for b in banks:
   if b['group'] in {'generic','scenes'}:
    text=b['template'].replace('{name}',name) if '{name}' in b['template'] else f"{name}! {b['template']}"
    cases.append({'group':'configured_name','text':text,'name':name})
else:
 cases=[{'group':b['group'],'text':b['template'].replace('{name}, ','').replace('{name}','little one'),'name':None} for b in banks]
if a.waveform_dir:a.waveform_dir.mkdir(parents=True,exist_ok=True)
rows=[];start=time.monotonic()
for i,c in enumerate(cases):
 row={'index':i,**c};t=time.monotonic()
 try:
  y,chunks=renderer.generate(c['text'],c['name']);seconds=len(y)/24000;peak=float(np.max(np.abs(y)));rms=float(np.sqrt(np.mean(y.astype(np.float64)**2)))
  row.update(samples=len(y),sample_rate=24000,duration_seconds=seconds,peak=peak,rms=rms,chunks=len(chunks),valid=bool(np.isfinite(y).all()) and .05<=seconds<=max(10,len(c['text'].split())*3) and 0<rms and peak<=2)
  if a.waveform_dir:np.save(a.waveform_dir/f'{i:04d}.npy',y)
 except Exception as exc:row.update(valid=False,error=repr(exc))
 row['generation_seconds']=time.monotonic()-t;row['rss_kib']=int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')//1024;rows.append(row)
 if (i+1)%50==0:print(json.dumps({'completed':i+1,'failed':sum(not r['valid'] for r in rows)}),flush=True)
summary={'total':len(rows),'failed':sum(not r['valid'] for r in rows),'elapsed_seconds':time.monotonic()-start,'source_hashes':hashes,'rss_range_kib':[min(r['rss_kib'] for r in rows),max(r['rss_kib'] for r in rows)],'integration_approved':False,'limitations':['waveform validity is not acoustic equivalence','names are English-TTS approximations','no Android playback or callbacks']}
summary['frontend_dependencies_sha256']=frontend_fingerprint()
(HERE/'results'/('renderer-names.json' if a.names else 'renderer-fixed.json')).write_text(json.dumps({'summary':summary,'records':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary),flush=True);raise SystemExit(bool(summary['failed']))

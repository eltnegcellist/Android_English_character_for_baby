#!/usr/bin/env python3
"""Independent English ASR comparison; not a perceptual voice-quality score."""
import argparse,json,re,time
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly
from faster_whisper import WhisperModel
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--stable',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--corpus',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
p.add_argument('--no-repeat-ngram-size',type=int,default=0)
a=p.parse_args();model=WhisperModel(str(a.model),device='cpu',compute_type='int8',cpu_threads=2);rows=[];start=time.monotonic()

def normalize(text):
 s=text.lower().replace('’',"'")
 for old,new in [("i'm",'i am'),("you're",'you are'),("let's",'let us'),("it's",'it is')]:s=s.replace(old,new)
 return re.findall('[a-z]+',s)

def distance(x,y):
 prev=list(range(len(y)+1))
 for i,c in enumerate(x,1):
  current=[i]
  for j,d in enumerate(y,1):current.append(min(current[-1]+1,prev[j]+1,prev[j-1]+(c!=d)))
  prev=current
 return prev[-1]

for i,item in enumerate(json.loads(a.corpus.read_text())):
 expected=normalize(item['text']);row={'index':i,'text':item['text'],'reference_words':len(expected)}
 for label,root in [('stable',a.stable),('candidate',a.candidate)]:
  original=np.load(root/f'{i:04d}.npy');peak=float(np.max(np.abs(original)));gain=min(1.8,max(1.0,.92/peak)) if peak>0 else 1.0
  audio=resample_poly(np.clip(original*gain,-1,1),2,3).astype(np.float32)
  segments,info=model.transcribe(audio,language='en',beam_size=5,temperature=0,condition_on_previous_text=False,vad_filter=False,no_repeat_ngram_size=a.no_repeat_ngram_size)
  transcript=' '.join(s.text.strip() for s in segments);row[label]={'transcript':transcript,'word_errors':distance(expected,normalize(transcript))}
 rows.append(row)
 if (i+1)%20==0:print(json.dumps({'compared':i+1}),flush=True)
words=sum(r['reference_words'] for r in rows);old=sum(r['stable']['word_errors'] for r in rows)/words;new=sum(r['candidate']['word_errors'] for r in rows)/words
summary={'total':len(rows),'reference_words':words,'stable_wer':old,'candidate_wer':new,'wer_delta':new-old,'predeclared_max_delta':0.05,'asr_regression_gate_passed':new-old<=0.05,'elapsed_seconds':time.monotonic()-start,'integration_approved':False,'limitations':['ASR is an imperfect proxy','does not measure naturalness or speaker similarity','no name acoustic qualification','Android untested']}
summary['decoder_no_repeat_ngram_size']=a.no_repeat_ngram_size
a.output.write_text(json.dumps({'summary':summary,'model_path':str(a.model),'records':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary),flush=True)
raise SystemExit(not summary['asr_regression_gate_passed'])

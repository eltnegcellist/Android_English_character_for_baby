#!/usr/bin/env python3
"""Old GPL-containing TTS reference ONLY; must run in its separate environment."""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
import sherpa_onnx
p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True);p.add_argument('--corpus',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--waveform-dir',type=Path)
a=p.parse_args();root=a.assets
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(kitten=sherpa_onnx.OfflineTtsKittenModelConfig(model=str(root/'model.fp32.onnx'),voices=str(root/'voices.bin'),tokens=str(root/'tokens.txt'),data_dir=str(root/'espeak-ng-data')),num_threads=2,debug=False,provider='cpu'),max_num_sentences=1)
engine=sherpa_onnx.OfflineTts(config);rows=[]
if a.waveform_dir:a.waveform_dir.mkdir(parents=True,exist_ok=True)
for i,item in enumerate(json.loads(a.corpus.read_text())):
 chunks=[];start=time.monotonic()
 def callback(samples,progress):chunks.append({'samples':len(samples),'progress':float(progress)});return 1
 y=engine.generate(item['text'],sid=7,speed=0.8,callback=callback);v=np.asarray(y.samples,dtype=np.float32)
 rows.append({**item,'samples':len(v),'sample_rate':y.sample_rate,'duration_seconds':len(v)/y.sample_rate,'rms':float(np.sqrt(np.mean(v.astype(np.float64)**2))),'peak':float(np.max(np.abs(v))),'finite':bool(np.isfinite(v).all()),'chunks':chunks,'generation_seconds':time.monotonic()-start})
 if a.waveform_dir:np.save(a.waveform_dir/f'{i:04d}.npy',v)
 if (i+1)%20==0:print(json.dumps({'completed':i+1}),flush=True)
a.output.write_text(json.dumps({'reference_only':True,'runtime':'sherpa-onnx 1.13.8','speaker_id':7,'requested_speed':0.8,'asset_hashes':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['model.fp32.onnx','voices.bin']},'records':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'completed':len(rows),'invalid':sum(not r['finite'] or not r['samples'] for r in rows)}),flush=True)

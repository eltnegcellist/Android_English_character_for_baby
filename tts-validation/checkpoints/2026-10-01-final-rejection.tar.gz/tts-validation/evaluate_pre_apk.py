#!/usr/bin/env python3
"""Fail-closed readiness ledger; never builds an APK or edits the application."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
from frontend_fingerprint import frontend_fingerprint
from validate_g2p import BASE,inventory
def read(name):return json.loads((HERE/'results'/name).read_text())
fixed=read('renderer-fixed.json');names=read('renderer-names.json');jvm=read('jvm-runtime-controller.json')
word=read('lite-word-summary.json');resource=read('jvm-resource-probe.json');compile=read('android-dependency-compile.json')
unbounded=read('asr-audio-comparison.json')['summary'];bounded=read('asr-audio-comparison-bounded-decoder.json')['summary']
sources=frontend_fingerprint()
fresh=all(x.get('frontend_dependencies_sha256')==sources for x in [word,fixed['summary'],names['summary']])
assert len(fixed['records'])==202 and len(names['records'])==780
assert [x['text'] for x in read('stable-audio-reference.json')['records']]==[x['text'] for x in fixed['records']]
production=['app','.github','tools','gradle','settings.gradle.kts','build.gradle.kts']
diff=subprocess.check_output(['git','diff','--name-only',BASE,'--',*production],cwd=HERE.parent,text=True).splitlines()
packages=inventory()
hits=[p['name'] for p in packages if re.search(r'\b(?:A?GPL|LGPL)\b|GNU (?:Library|Lesser|General)',p['license_metadata'],re.I)]
forbidden=[p['name'] for p in packages if p['name'].lower().replace('_','-') in {'num2words','misaki','phonemizer','phonemizer-fork','espeakng-loader','espeakng','sherpa-onnx','sherpa-onnx-core'}]
gates={
 'candidate_source_fresh':{'status':'PASS' if fresh else 'FAIL'},
 'host_dependency_metadata':{'status':'PASS' if not hits and not forbidden else 'FAIL','gpl_family_hits':hits,'forbidden_packages':forbidden,'scope':'Metadata inventory only; not final binary provenance proof'},
 'bounded_g2p':{'status':'PASS' if fresh and not word['failed_occurrences'] else 'FAIL','scope':'Independent fixed Lite segments/stress and focused fixtures; unrestricted Full not qualified'},
 'fixed_and_configured_name_generation':{'status':'PASS' if fixed['summary']['failed']==names['summary']['failed']==0 and fresh else 'FAIL','total':982},
 'jvm_onnx_cancellation':{'status':'PASS' if jvm['cancelled_runs']==jvm['regenerated_runs']==resource['cycles']==100 else 'FAIL','scope':'Linux JVM with real ONNX; Android native execution not established'},
 'controller_contract':{'status':'PASS' if jvm['controller_play_stop_restart_cycles']==100 else 'FAIL','scope':'Deterministic fake sink and queued dispatcher; real AudioTrack untested'},
 'android_api_compile':{'status':'PASS' if compile['compile_succeeded'] else 'FAIL','scope':'Official Android AAR and API 37.1; compile only'},
 'unbounded_asr_diagnostic':{'status':'PASS' if unbounded['asr_regression_gate_passed'] else 'FAIL','wer_delta':unbounded['wer_delta']},
 'bounded_decoder_asr_diagnostic':{'status':'PASS' if bounded['asr_regression_gate_passed'] else 'FAIL','wer_delta':bounded['wer_delta'],'scope':'Follow-up decoder robustness diagnostic; does not erase first failure'},
 'acoustic_equivalence':{'status':'BLOCKED','reason':'Expressive timing differences, unresolved pronunciation/voice naturalness and conflicting ASR diagnostics'},
 'android_g2p':{'status':'BLOCKED','reason':'Current frontend requires Python/spaCy; JVM probes use test-only plans, no native qualified Planner'},
 'full_and_arbitrary_names':{'status':'BLOCKED','reason':'No qualified unrestricted English OOV/foreign-name/context resolver'},
 'android_playback_lifecycle':{'status':'NOT_RUN','reason':'Actual AudioTrack/Android native tests depend on qualified G2P replacement; app not integrated'},
 'production_isolation':{'status':'PASS' if not diff else 'FAIL','changed_files':diff},
 'final_apk_inspection':{'status':'NOT_RUN','reason':'User scope ends before final APK inspection; integration gates still blocked'},
}
result={'baseline':BASE,'integration_approved':False,'pre_apk_ready':False,'apk_built':False,'gates':gates,'packages':packages,
 'kotlin_sources_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/'android-isolated').glob('*.kt'))},
 'decision':'BLOCKED: keep validation separate from app/main. APK inspection is not the sole remaining gate.'}
(HERE/'results/pre-apk-readiness.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['packages','kotlin_sources_sha256']},ensure_ascii=False,indent=2))
raise SystemExit(1)

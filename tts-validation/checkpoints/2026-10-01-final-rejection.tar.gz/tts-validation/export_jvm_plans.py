#!/usr/bin/env python3
"""Export passed, test-only phoneme plans. These are not an Android G2P port."""
import argparse,base64,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'candidates'))
from frontend_fingerprint import frontend_fingerprint
from utterance_renderer import Renderer

p=argparse.ArgumentParser()
p.add_argument('--dictionary',type=Path,required=True)
p.add_argument('--assets',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
gate=json.loads((HERE/'results/lite-word-summary.json').read_text())
if gate['frontend_dependencies_sha256']!=frontend_fingerprint() or gate['failed_occurrences'] or gate['missing_expectations']:
    raise SystemExit('Missing, stale or failing lexical gate')
renderer=Renderer(a.dictionary,a.assets)
rows=json.loads((HERE/'fixtures/comparison-corpus.json').read_text())
fixed=json.loads((HERE/'results/renderer-fixed.json').read_text())
if [row['text'] for row in rows]!=[row['text'] for row in fixed['records']]:
    raise SystemExit('Comparison fixture does not match the validated fixed corpus')
a.output.write_text('\n'.join('\t'.join([str(i),*(base64.b64encode(s.encode()).decode() for s in renderer.plan(row['text']))]) for i,row in enumerate(rows))+'\n')
print('Exported',len(rows),'test-only plans')

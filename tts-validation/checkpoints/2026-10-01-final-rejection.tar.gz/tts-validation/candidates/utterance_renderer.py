"""Validated whole-text G2P, then sentence/token chunks and cancellable ONNX runs."""
import re
import threading
import numpy as np
from clean_frontend import Frontend
from isolated_onnx import Engine
from audio_contract import shorten_pauses


class Cancelled(Exception): pass


class Cancellation:
    def __init__(self):
        self.event=threading.Event();self.lock=threading.Lock();self.options=None
    def cancel(self):
        with self.lock:
            self.event.set()
            if self.options is not None:self.options.terminate=True
    def attach(self,options):
        with self.lock:
            if self.event.is_set():raise Cancelled()
            self.options=options
    def detach(self,options):
        with self.lock:
            if self.options is options:self.options=None
    def check(self):
        if self.event.is_set():raise Cancelled()


def chunk_ipa(ipa,max_tokens=400):
    if not ipa:raise ValueError('Empty phoneme plan')
    # Split already-normalized phonemes, so decimal points/abbreviations in text
    # are not guessed here. This preserves G2P's whole-text grammatical context.
    sentences=[s.strip() for s in re.split(r'(?<=[.!?])\s+',ipa) if s.strip()]
    chunks=[]
    for sentence in sentences:
        current=[];cost=0
        for char in sentence:
            size=2 if char=='.' else 1
            if cost+size+3>max_tokens:
                if not current:raise ValueError('Invalid token bound')
                chunks.append(''.join(current));current=[];cost=0
            current.append(char);cost+=size
        if current:chunks.append(''.join(current))
    return chunks


class Renderer:
    def __init__(self,dictionary,assets):
        self.frontend=Frontend(dictionary);self.engine=Engine(assets)
    def plan(self,text,name=None):
        r=self.frontend(text,japanese_name=name)
        if r['unresolved'] or r['unresolved_meaning'] or not r['ipa']:raise ValueError('Unresolved text; no guessing fallback')
        return chunk_ipa(r['ipa'],int(self.engine.meta['max_token_len']))
    def generate(self,text,name=None,cancellation=None):
        token=cancellation or Cancellation();token.check()
        chunks=self.plan(text,name);parts=[]
        for ipa in chunks:
            token.check();parts.append(shorten_pauses(self.engine.generate(ipa,cancellation=token)))
        token.check()
        return np.concatenate(parts),chunks

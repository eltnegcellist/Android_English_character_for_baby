"""Output-only timing/PCM contract. Never changes microphone VAD or ASR.

Silence thresholds and float32 rounding follow the Apache-2.0 Sherpa 1.13.8
GeneratedAudio contract. Implementation is independent NumPy interval selection.
See SHERPA_CONTRACT_NOTICE and SHERPA_CONTRACT_LICENSE.
"""
import numpy as np


def shorten_pauses(samples, sample_rate=24000):
    y = np.asarray(samples, dtype=np.float32)
    if y.ndim != 1 or not y.size or not np.isfinite(y).all():
        raise ValueError('Invalid audio')
    threshold = int(sample_rate * .2)
    quiet = np.abs(y) <= np.float32(.01)
    transitions = np.diff(np.r_[False, quiet, False].astype(np.int8))
    starts, ends = np.flatnonzero(transitions == 1), np.flatnonzero(transitions == -1)
    parts = []; previous = 0
    for start, end in zip(starts, ends):
        length = end - start
        if length < threshold or (end == len(y) and length == threshold):
            continue
        keep = int(np.float32(length) * np.float32(.2))
        parts.append(y[previous:start + keep]); previous = end
    parts.append(y[previous:])
    return np.concatenate(parts)


def pcm16(samples):
    y = np.asarray(samples, dtype=np.float32)
    if y.ndim != 1 or not y.size or not np.isfinite(y).all():
        raise ValueError('Invalid audio')
    peak = np.max(np.abs(y))
    gain = np.minimum(np.float32(1.8), np.maximum(np.float32(1), np.float32(.92) / peak)) if peak > 0 else np.float32(1)
    return (np.clip(y * gain, -1, 1) * np.float32(32767)).astype(np.int16)
